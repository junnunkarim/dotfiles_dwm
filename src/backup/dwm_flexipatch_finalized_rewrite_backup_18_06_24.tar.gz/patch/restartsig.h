static void sighup(int unused);
static void sigterm(int unused);

